# -*- coding: utf-8 -*-
"""

"""

from __future__ import division
from __future__ import print_function
from __future__ import absolute_import

__author__ = "timmyliang"
__email__ = "820472580@qq.com"
__date__ = "2020-12-11 15:29:19"

import os
import tempfile
import subprocess

# imagemagick = '"%s"' % r"C:\Program Files\Autodesk\Maya2019\bin\imconvert.exe"
imagemagick = '"%s"' % r"G:\ImageMagick\magick.exe"
DIR = os.path.dirname(__file__)
# folder = os.path.join(DIR, "colors")
# if not os.path.isdir(folder):
#     os.mkdir(folder)
# for f in os.listdir(folder):
#     os.remove(os.path.join(folder, f))

gradient_1 = os.path.join(tempfile.gettempdir(),"gradient_1.png")
gradient_2 = os.path.join(tempfile.gettempdir(),"gradient_2.png")
mask = os.path.join(tempfile.gettempdir(),"mask.png")

# NOTE 遍历图片
for img in os.listdir(DIR):
    if not img.endswith(".png"):
        continue

    path = os.path.join(DIR, img)
    name = os.path.splitext(img)[0]
    output_path = os.path.join(DIR, "output.png")
    next_name = float(name) - 0.1
    next_path = os.path.join(DIR, "%s.png" % (next_name))
    if not os.path.exists(next_path):
        continue
    
    command = " ".join(
        [
            imagemagick,
            path,
            "-negate",
            "-morphology Distance Euclidean:4,100^!",
            "-negate",
            gradient_1,
        ]
    )
    subprocess.call(command)
    
    command = " ".join(
        [
            imagemagick,
            next_path,
            "-morphology Distance Euclidean:4,100^!",
            gradient_2,
        ]
    )
    subprocess.call(command)
    
    # NOTES(timmyliang) fancomp 
    command = " ".join(
        [
            imagemagick,
            gradient_1,
            gradient_2,
            "( -clone 1 -evaluate Divide 2 )",
            "( -clone 0-1 -compose Mathematics",
            "-define compose:args=0,0.5,-0.5,0.5 -composite )",
            "-delete 0-1",
            "-compose DivideSrc -composite",
            output_path
        ]
    )
    subprocess.call(command)
    
    # NOTES(timmyliang) generate mask
    command = " ".join(
        [
            imagemagick,
            next_path,
            path,
            '-compose Change-mask -composite',
            '-background black -alpha background -alpha off',
            mask
        ]
    )
    subprocess.call(command)
    
    command = " ".join(
        [
            imagemagick,
            output_path,
            mask,
            '-alpha Off -compose CopyOpacity -composite',
            output_path
        ]
    )
    subprocess.call(command)

# "C:\Program Files\Autodesk\Maya2019\bin\imconvert.exe" ^
#     "C:\Users\timmyliang\Desktop\file_test\2020-12-10\test\0.9.png" ^
#     -negate ^
#     -morphology Distance Euclidean:4,100^! ^
#     -negate ^
#     "C:\Users\timmyliang\Desktop\file_test\2020-12-10\test\0.9gradient.png"

# "C:\Program Files\Autodesk\Maya2019\bin\imconvert.exe" ^
#     "C:\Users\timmyliang\Desktop\file_test\2020-12-10\test\0.8.png" ^
#     -morphology Distance Euclidean:4,100^! ^
#     "C:\Users\timmyliang\Desktop\file_test\2020-12-10\test\0.8gradient.png"


# "C:\Program Files\Autodesk\Maya2019\bin\imconvert.exe" ^
#   "C:\Users\timmyliang\Desktop\file_test\2020-12-10\test\0.9gradient.png" ^
#   "C:\Users\timmyliang\Desktop\file_test\2020-12-10\test\0.8gradient.png" ^
#   ( -clone 1 -evaluate Divide 2 ) ^
#   ( -clone 0-1 ^
#     -compose Mathematics ^
#       -define compose:args=0,0.5,-0.5,0.5 ^
#       -composite ^
#   ) ^
#   -delete 0-1 ^
#   -compose DivideSrc -composite ^
#   "C:\Users\timmyliang\Desktop\file_test\2020-12-10\test\output.png"

# "C:\Program Files\Autodesk\Maya2019\bin\imconvert.exe" ^
#     "C:\Users\timmyliang\Desktop\file_test\2020-12-10\test\0.8.png" ^
#     "C:\Users\timmyliang\Desktop\file_test\2020-12-10\test\0.9.png" ^
#     -fx "u-v" ^
#     "C:\Users\timmyliang\Desktop\file_test\2020-12-10\test\mask.png"

# "C:\Program Files\Autodesk\Maya2019\bin\imconvert.exe" ^
#   "C:\Users\timmyliang\Desktop\file_test\2020-12-10\test\output.png" ^
#   "C:\Users\timmyliang\Desktop\file_test\2020-12-10\test\mask.png" ^
#   -alpha Off -compose CopyOpacity -composite ^
#   "C:\Users\timmyliang\Desktop\file_test\2020-12-10\test\output.png"

